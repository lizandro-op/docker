require 'minitest/spec'

describe_recipe 'rails::configure' do
  include MiniTest::Chef::Resources
  include MiniTest::Chef::Assertions

end
