#
# Include the following recipes, that deal with testing internal compents not
# testable with specs.
include_recipe 'opsworks_commons::gem_support_test'
